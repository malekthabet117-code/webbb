-- ============================================
-- BookNomad – Base de données corrigée
-- Correction : table emprunts avec id AUTO_INCREMENT
-- permettant à un utilisateur de réemprunter un livre
-- ============================================

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";
SET NAMES utf8mb4;

-- Base de données : `booknomad`

-- ============================================
-- Table `utilisateurs`
-- ============================================
CREATE TABLE `utilisateurs` (
  `id`       int(11)      NOT NULL AUTO_INCREMENT,
  `nom`      varchar(100) DEFAULT NULL,
  `prenom`   varchar(100) DEFAULT NULL,
  `email`    varchar(100) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role`     varchar(20)  DEFAULT 'user',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `utilisateurs` (`id`, `nom`, `prenom`, `email`, `password`, `role`) VALUES
(1, 'Ali',    'Thabet', 'ali@gmail.com',              '1234', 'admin'),
(2, 'Sami',   'Fhal',   'sami@gmail.com',             '1234', 'user'),
(3, 'Malek',  'Thabet', 'malekthabet117@gmail.com',   '1234', 'user');

ALTER TABLE `utilisateurs` AUTO_INCREMENT = 4;

-- ============================================
-- Table `livres`
-- ============================================
CREATE TABLE `livres` (
  `id`          int(11)      NOT NULL AUTO_INCREMENT,
  `titre`       varchar(255) DEFAULT NULL,
  `auteur`      varchar(255) DEFAULT NULL,
  `description` text         DEFAULT NULL,
  `categorie`   varchar(50)  DEFAULT NULL,
  `statut`      enum('disponible','emprunté') DEFAULT 'disponible',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT INTO `livres` (`id`, `titre`, `auteur`, `description`, `categorie`, `statut`) VALUES
(1, 'JavaScript Basics', 'John Doe', 'Livre pour apprendre les bases de JavaScript.', 'Informatique', 'disponible'),
(2, 'Science Secret',    'Ali Ben',  'Un voyage fascinant dans les secrets de la science moderne.', 'Science', 'disponible'),
(3, 'Me or You',         'Sara Dev', 'Une réflexion philosophique profonde sur l\'identité.', 'Philosophy', 'disponible'),
(4, 'Français Pratique', 'Mike',     'Apprenez et maîtrisez la langue française.', 'Francais', 'disponible');

ALTER TABLE `livres` AUTO_INCREMENT = 5;

-- ============================================
-- Table `emprunts`
-- ✅ CORRECTION : ajout d'un id AUTO_INCREMENT comme clé primaire
-- L'ancienne clé (utilisateur_id, livre_id) empêchait un user
-- de réemprunter un livre déjà retourné ou refusé.
-- ============================================
CREATE TABLE `emprunts` (
  `id`             int(11)  NOT NULL AUTO_INCREMENT,
  `utilisateur_id` int(11)  NOT NULL,
  `livre_id`       int(11)  NOT NULL,
  `date_emprunt`   datetime DEFAULT NULL,
  `date_retour`    datetime DEFAULT NULL,
  `status`         enum('en_attente','valide','refuse') DEFAULT 'en_attente',
  PRIMARY KEY (`id`),
  KEY `utilisateur_id` (`utilisateur_id`),
  KEY `livre_id` (`livre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Données de test
INSERT INTO `emprunts` (`utilisateur_id`, `livre_id`, `date_emprunt`, `date_retour`, `status`) VALUES
(2, 2, '2026-03-23 17:49:55', '2026-03-24 01:55:08', 'refuse'),
(3, 3, '2026-03-24 20:23:41', '2026-03-24 20:29:45', 'refuse');

ALTER TABLE `emprunts` AUTO_INCREMENT = 3;

-- ============================================
-- Contraintes de clés étrangères
-- ============================================
ALTER TABLE `emprunts`
  ADD CONSTRAINT `emprunts_ibfk_1` FOREIGN KEY (`utilisateur_id`) REFERENCES `utilisateurs` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `emprunts_ibfk_2` FOREIGN KEY (`livre_id`)       REFERENCES `livres` (`id`)       ON DELETE CASCADE;

COMMIT;